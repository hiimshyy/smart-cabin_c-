# Environment + shell functions cho RetinaFace + MobileFaceNet demo (A733)
#
# CÁCH DÙNG:
#   source env.sh                          (chỉ session hiện tại)
#   echo "source $(pwd)/env.sh" >> ~/.bashrc   (áp vĩnh viễn)
#
# Sau khi source, có các lệnh:
#   face_run [DB]              — chạy realtime match (default: db/faces_all.fdb)
#   face_detect                — chạy detect-only (không recognition)
#   face_capture NAME [COUNT]  — chụp N frames (default 5)
#   face_add NAME IMG [IMG..]  — thêm 1 người vào DB
#   face_enroll [DIR] [OUT]    — rebuild DB từ folder (default: faces/ → db/faces_all.fdb)
#   face_bench [N]             — chạy N frames bench (default 100)
#   face_ls                    — liệt kê DB và số identity
#   face_help                  — in help này

# ---- Path setup ----
export FACE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export FACE_DET_MODEL="$FACE_ROOT/model/Retinaface_resnet50_320_uint8_a733.nb"
export FACE_DET_MODEL_320="$FACE_ROOT/model/Retinaface_resnet50_320_uint8_a733.nb"
export FACE_DET_MODEL_640="$FACE_ROOT/model/retinaface_resnet50_640_uint8_a733.nb"
export FACE_DET_MODEL_SCRFD="$FACE_ROOT/model/face_det/scrfd_2.5g_bnkps640_uint8_a733.nb"
export FACE_RECOG_MODEL="$FACE_ROOT/model/face_recog/w600k_mbf_uint8_a733.nb"
export FACE_DB_DIR="$FACE_ROOT/db"
export FACE_DB_DEFAULT="$FACE_DB_DIR/faces_all.fdb"
export FACE_FACES_DIR="$FACE_ROOT/faces"

# X11 display (chỉ set nếu chưa có)
[ -z "$DISPLAY" ]   && export DISPLAY=:0.0
[ -z "$XAUTHORITY" ] && export XAUTHORITY="$HOME/.Xauthority"

# Silence benign OpenCV/GStreamer warnings on RTSP (duration query, etc.)
# Set OPENCV_LOG_LEVEL=WARNING or DEBUG for troubleshooting.
[ -z "$OPENCV_LOG_LEVEL" ] && export OPENCV_LOG_LEVEL=ERROR

# ---- Shell functions ----
face_run() {
    local db="${1:-$FACE_DB_DEFAULT}"
    local thr="${2:-0.35}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL" \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr")
}

# Chạy live match với RTSP camera. URL bắt buộc, DB & threshold tùy chọn.
face_run_rtsp() {
    if [ -z "$1" ]; then
        echo "Usage: face_run_rtsp URL [DB] [THR] [LATENCY_MS]"
        echo "Example: face_run_rtsp rtsp://admin:pass@192.168.1.100:554/stream1"
        return 1
    fi
    local url="$1"
    local db="${2:-$FACE_DB_DEFAULT}"
    local thr="${3:-0.35}"
    local lat="${4:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL" \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr" \
        --source "$url" --gst-latency "$lat")
}

face_detect() {
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL")
}

face_capture() {
    if [ -z "$1" ]; then
        echo "Usage: face_capture NAME [COUNT] [MIN_FACE_PX]"
        return 1
    fi
    local name="$1"
    local count="${2:-5}"
    local minface="${3:-100}"
    (cd "$FACE_ROOT" && ./capture_person \
        --name "$name" --count "$count" \
        --min-face-px "$minface" \
        --det-model "$FACE_DET_MODEL")
}

face_add() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "Usage: face_add NAME IMG [IMG ...] [--replace|--merge]"
        echo "  DB target: $FACE_DB_DEFAULT (set FACE_DB_DEFAULT to change)"
        return 1
    fi
    local name="$1"; shift
    local images=()
    local flags=()
    for arg in "$@"; do
        case "$arg" in
            --replace|--merge) flags+=("$arg") ;;
            *)                 images+=(--image "$arg") ;;
        esac
    done
    (cd "$FACE_ROOT" && ./add_person \
        --name "$name" \
        "${images[@]}" \
        --db "$FACE_DB_DEFAULT" \
        --det-model "$FACE_DET_MODEL" \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        "${flags[@]}")
}

face_enroll() {
    local dir="${1:-$FACE_FACES_DIR}"
    local out="${2:-$FACE_DB_DEFAULT}"
    (cd "$FACE_ROOT" && ./enroll_faces \
        --dir "$dir" --out "$out" \
        --det-model "$FACE_DET_MODEL" \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr)
}

face_bench() {
    local n="${1:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL" \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$FACE_DB_DEFAULT" --match-thr 0.35 \
        --frames "$n")
}

# ---- 640-input variants (for A/B testing new model) ----
face_run640() {
    local db="${1:-$FACE_DB_DEFAULT}"
    local thr="${2:-0.35}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_640" \
        --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr")
}

face_detect640() {
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_640" --input-size 640)
}

# RTSP với model 640
face_run_rtsp640() {
    if [ -z "$1" ]; then
        echo "Usage: face_run_rtsp640 URL [DB] [THR] [LATENCY_MS]"
        return 1
    fi
    local url="$1"
    local db="${2:-$FACE_DB_DEFAULT}"
    local thr="${3:-0.35}"
    local lat="${4:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_640" \
        --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr" \
        --source "$url" --gst-latency "$lat")
}

# Bench RTSP với 640 (đo FPS thực tế trên stream mạng)
face_bench_rtsp640() {
    if [ -z "$1" ]; then
        echo "Usage: face_bench_rtsp640 URL [N_FRAMES] [DB]"
        return 1
    fi
    local url="$1"
    local n="${2:-100}"
    local db="${3:-$FACE_DB_DEFAULT}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_640" \
        --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr 0.35 \
        --source "$url" \
        --frames "$n")
}

face_bench_rtsp320() {
    if [ -z "$1" ]; then
        echo "Usage: face_bench_rtsp320 URL [N_FRAMES] [DB]"
        return 1
    fi
    local url="$1"
    local n="${2:-100}"
    local db="${3:-$FACE_DB_DEFAULT}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_320" \
        --input-size 320 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr 0.35 \
        --source "$url" \
        --frames "$n")
}

# ---- SCRFD 2.5g_bnkps 640 variants (lightweight, ~5x faster than RetinaFace) ----
face_run_scrfd() {
    local db="${1:-$FACE_DB_DEFAULT}"
    local thr="${2:-0.35}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr")
}

face_detect_scrfd() {
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640)
}

face_bench_scrfd() {
    local n="${1:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$FACE_DB_DEFAULT" --match-thr 0.35 \
        --frames "$n")
}

face_run_rtsp_scrfd() {
    if [ -z "$1" ]; then
        echo "Usage: face_run_rtsp_scrfd URL [DB] [THR] [LATENCY_MS]"
        return 1
    fi
    local url="$1"
    local db="${2:-$FACE_DB_DEFAULT}"
    local thr="${3:-0.35}"
    local lat="${4:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr "$thr" \
        --source "$url" --gst-latency "$lat")
}

face_bench_rtsp_scrfd() {
    if [ -z "$1" ]; then
        echo "Usage: face_bench_rtsp_scrfd URL [N_FRAMES] [DB]"
        return 1
    fi
    local url="$1"
    local n="${2:-100}"
    local db="${3:-$FACE_DB_DEFAULT}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$db" --match-thr 0.35 \
        --source "$url" \
        --frames "$n")
}

# Enroll DB using SCRFD (better landmarks → better runtime match if using SCRFD)
face_enroll_scrfd() {
    local dir="${1:-$FACE_FACES_DIR}"
    local out="${2:-$FACE_DB_DEFAULT}"
    (cd "$FACE_ROOT" && ./enroll_faces \
        --dir "$dir" --out "$out" \
        --det-model "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr)
}

# Capture person face frames using SCRFD gating
face_capture_scrfd() {
    if [ -z "$1" ]; then
        echo "Usage: face_capture_scrfd NAME [COUNT] [MIN_FACE_PX]"
        return 1
    fi
    local name="$1"
    local count="${2:-5}"
    local minface="${3:-100}"
    (cd "$FACE_ROOT" && ./capture_person \
        --name "$name" --count "$count" \
        --min-face-px "$minface" \
        --det-model "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640)
}

# Add one identity to DB using SCRFD detector
face_add_scrfd() {
    if [ -z "$1" ] || [ -z "$2" ]; then
        echo "Usage: face_add_scrfd NAME IMG [IMG ...] [--replace|--merge]"
        return 1
    fi
    local name="$1"; shift
    local images=()
    local flags=()
    for arg in "$@"; do
        case "$arg" in
            --replace|--merge) flags+=("$arg") ;;
            *)                 images+=(--image "$arg") ;;
        esac
    done
    (cd "$FACE_ROOT" && ./add_person \
        --name "$name" \
        "${images[@]}" \
        --db "$FACE_DB_DEFAULT" \
        --det-model "$FACE_DET_MODEL_SCRFD" \
        --detector scrfd --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        "${flags[@]}")
}

face_bench320() {
    local n="${1:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_320" \
        --input-size 320 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$FACE_DB_DEFAULT" --match-thr 0.35 \
        --frames "$n")
}

face_bench640() {
    local n="${1:-100}"
    (cd "$FACE_ROOT" && ./face_recog_app "$FACE_DET_MODEL_640" \
        --input-size 640 \
        --recog-model "$FACE_RECOG_MODEL" \
        --recog-dim 512 --recog-bgr \
        --face-db "$FACE_DB_DEFAULT" --match-thr 0.35 \
        --frames "$n")
}

face_ls() {
    echo "DB files in $FACE_DB_DIR:"
    ls -la "$FACE_DB_DIR"/*.fdb 2>/dev/null
    echo ""
    echo "Enroll folders in $FACE_FACES_DIR:"
    ls -1 "$FACE_FACES_DIR" 2>/dev/null | while read n; do
        [ -d "$FACE_FACES_DIR/$n" ] && printf "  %-20s  %d ảnh\n" \
            "$n" "$(ls "$FACE_FACES_DIR/$n"/*.jpg 2>/dev/null | wc -l)"
    done
}

face_help() {
    cat <<'EOF'
==============================================================
 RetinaFace + MobileFaceNet — Face Recognition Shortcuts
==============================================================
 face_run [DB] [THR]           Live match (default DB: db/faces_all.fdb)
 face_run_rtsp URL [DB] [THR]  Live match từ RTSP camera (GStreamer)
 face_detect                   Detect-only (bỏ recognition)
 face_capture NAME [N] [MIN]   Chụp N frames của 1 người
 face_add NAME IMG [IMG...]    Thêm người từ ảnh (--replace/--merge)
 face_enroll [DIR] [OUT]       Rebuild toàn bộ DB
 face_bench [N]                Chạy N frames + in benchmark (320)
 face_bench320 [N]             Bench với model 320 (explicit)
 face_bench640 [N]             Bench với model 640 (A/B test)
 face_run640 [DB] [THR]        Live match với model 640
 face_detect640                Detect-only với model 640
 face_run_rtsp640 URL [DB]     Live match RTSP với model 640
 face_bench_rtsp320 URL [N]    Bench RTSP với model 320
 face_bench_rtsp640 URL [N]    Bench RTSP với model 640 (A/B stream test)

 --- SCRFD (light, fast) ---
 face_run_scrfd [DB] [THR]     Live match với SCRFD 2.5g_bnkps 640 (USB cam)
 face_detect_scrfd             Detect-only SCRFD
 face_bench_scrfd [N]          Bench SCRFD (USB cam)
 face_run_rtsp_scrfd URL [DB]  Live match RTSP với SCRFD
 face_bench_rtsp_scrfd URL [N] Bench RTSP với SCRFD
 face_enroll_scrfd [DIR] [OUT] Rebuild DB dùng SCRFD (khuyến nghị nếu chọn SCRFD)
 face_capture_scrfd NAME [N]   Chụp frames với SCRFD detect gate
 face_add_scrfd NAME IMG [...] Thêm người vào DB dùng SCRFD

 face_ls                       Liệt kê DB và enroll folders
 face_help                     In help này

 Ví dụ:
   face_capture alice 8
   face_add bob /photos/bob.jpg /photos/bob2.jpg
   face_add alice new.jpg --merge
   face_run
   face_enroll                 # rebuild sau khi có nhiều folder mới
==============================================================
EOF
}

echo "[face] loaded shortcuts — gõ 'face_help' để xem"
